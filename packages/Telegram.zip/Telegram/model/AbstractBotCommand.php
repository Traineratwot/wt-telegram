<?php

	namespace components\Telegram\model;

	abstract class AbstractBotCommand extends __AbstractBotCommand
	{

	}

