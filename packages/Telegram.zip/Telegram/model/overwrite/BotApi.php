<?php

	namespace components\Telegram\model\overwrite;


	class BotApi extends \TelegramBot\Api\BotApi
	{

	}